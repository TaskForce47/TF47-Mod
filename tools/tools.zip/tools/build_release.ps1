.\hemtt.ext clean
.\hemtt.exe build --release
pause
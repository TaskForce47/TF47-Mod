hemtt.exe clean
hemtt.exe build